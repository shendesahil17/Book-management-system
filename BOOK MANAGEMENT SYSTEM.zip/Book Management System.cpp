/* Book Management System :
Problem Statement:
A Book Management System is required to efficiently organize and manage 
information about books. The system should support various operations, 
including adding, removing, searching, updating, and displaying book records 
based on attributes such as Book ID, Book Name, Author Name, Price, and 
Rating. Additionally, the system should provide the capability to show details 
of books written by a specific author, display the top 3 books based on price 
and rating, and access information about all the books in the database.
 */
using namespace std;
#include <iostream>
#include <string.h>

 struct book
{
    int id;
    char bname[50];
    char author[50];
    double price;
    int ratings;
    
    
    // DEFAULT CONSTRUCTOR
    Book()
    {
    	this->id = 0;
    	this->ratings = 0;
    	this->price = 0;
    	strcpy(this->bname ,"NO NAME");
    	strcpy(this->author,"NO NAME");
	}
	// PARAMETRIZED CONSTRUCTOR
	Book (int x , double y ,int q, const char* bn, const char*an)
	{
	   	this->id = x;
    	this->price = y;
    	this->ratings = q;
        strcpy(this->bname,bn);
        strcpy(this->author,an);
        
	}
	// DISPLAY 
	void display()
    {
//    	cout<<"\n BOOK ID :"<<this->id<<"\n";
//    	cout<<"\n BOOK NAME : "<<this->bname<<"\n";
//    	cout<<"\n PRICE : "<<this->price<<endl;
//    	cout<<"\n RATINGS : "<<this->ratings<<endl;
//    	cout<<"\n AUTHOR NAME  :"<<this->author<<endl;
    	cout<<"          \n**Available Book list**\n";
			cout<<"\n-----------------------------------------------------------------------------------";
			cout<<"\n|   BOOK ID   |     BOOK NAME    |    AUTHOR NAME     |     PRICE     |  RATINGS  |";
			cout<<"\n-----------------------------------------------------------------------------------";
			cout<<"\n|"<<"\t"<< this->id<<"\t"<<"|"<<"\t"<<this->bname<<"\t"<<"|"<<"\t"<<this->author<<"\t"<<"|"<<"\t"<<this->ratings<<"\t"<<"|"<<"\t"<<this->price<<"\t"<<"|";        
		    cout<<"\n-----------------------------------------------------------------------------------";
    }

    // Setters for id
    void setid(int a)
    {
        this->id = a;
    }

    // Getters for id 
    int getid()
    {
        return this->id;
    }
    // Setters for price
    void setprice(double b)
    {
        this->price = b;
    }
    // Getters for price
    double getprice()
    {
        return this->price;
    }
    // Setters  for ratings
    void setratings(int c)
    {
        this->ratings = c;
    }
    // Getters for ratings
    int getratings()
    {
        return this->ratings;
    } 
	// Setters for book name
    void setbname(char *bn)
    {
        strcpy(this->bname, bn);
    }
    // Getters for  book name 
    char* getbname()
    {
        return this->bname;
    } 
    	// Setters for author name
    void setauthor(char *an)
    {
        strcpy(this->author, an);
    }
    // Getters for author  name 
    char* getauthor()
    {
        return this->author;
    } 
} ;

void addbook(book*, int *);
void displayallbooks(book*, int);
void searchbookbyid(book*, int, int);
void searchbookbyname(book*, int, char*);
void searchbookbyauthor(book*, int, char*);
void top3byprice(book*, int );
void top3byratings(book*, int);
void removebook(book*, int*, int);
void updatebook(book*, int, int, double, int);

int main() 
{
    int n = 0;
    book b[300];
    int choice;
int *a;
    //a=(int*)malloc(sizeof(int)*n);
    a=new int[n];
    while (1) 
	{
    cout<<"\n ***** WELCOME TO CODEX LIBRARY *****\n";
        cout<<"**********Book Management System**********\n";
        
        cout<<"|---------------------------------------------------------|\n";
    	cout<<"|  Option  |             Description                      |\n";
		cout<<"|---------------------------------------------------------|\n";
		cout<<"|    1     |  ADD BOOK                                    |\n";
	    cout<<"|    2     |  DISPLAY ALL BOOKS                           |\n";
		cout<<"|    3     |  SEARCH BOOK                                 |\n";
		cout<<"|    4     |  TOP 3 BY PRICE                              |\n";
		cout<<"|    5     |  TOP 3 BY RATINGS                            |\n";
		cout<<"|    6     |  REMOVE BOOK                                 |\n";
		cout<<"|    7     |  UPDATE BOOK                                 |\n";
		cout<<"|    8     |  EXIT                                        |\n";
		cout<<"|---------------------------------------------------------|\n";


        	cout<<"Enter your choice: ";
       cin>>choice;

        switch (choice)
		 {
		 	
            case 1:
                addbook(b, &n);
                break;
            case 2:
                for(int i = 0;i<n;i++)
            	{
            	b[i].display();
				}
                break;
                int searchChoice;
            case 3:
               	cout<<"SEARCH OPTION:\n";
                	cout<<"1. SEARCH BY ID\n 2. SEARCH BY BOOK NAME\n 3. SEARCH BY AUTHOR NAME\n";
                	cout<<"Enter your search option: ";
                cin>>searchChoice;

                switch (searchChoice) 
				{
					int searchid;
                    case 1:
                       	cout<<"Enter the ID of the book for search: ";
                        cin>>searchid;
                        searchbookbyid(b, n, searchid);
                        break;
                    char searchName[50];    
                    case 2:
                        	cout<<"Enter the name of the book for search: ";
                       cin>> searchName;
                        searchbookbyname(b, n, searchName);
                        break;
                    char searchAuthor[50];    
                    case 3:
                        	cout<<"Enter the name of the author for search: ";
                        cin>> searchAuthor;
                        searchbookbyauthor(b, n, searchAuthor);
                        break;
                    default:
                        	cout<<"\nINVALID CHOICE!! ENTER A CORRECT CHOICE FROM THE GIVEN OPTIONS.\n";
                }
                break;
            case 4:
                top3byprice(b, n);
                break;
            case 5:
                top3byratings(b, n);
                break;
            int removeId;
            case 6:
                	cout<<"Enter the ID of the book to remove: ";
                cin>>removeId;
                removebook(b, &n, removeId);
                break;
            int id;
            double newPrice;
            int newRating;    
            case 7:
               	cout<<"Enter the ID of the book to update: ";
               cin>>id;
                	cout<<"Enter the new price for the book: ";
                cin>>newPrice;
                	cout<<"Enter the new rating for the book: ";
                cin>>newRating;
                updatebook(b, n, id, newPrice, newRating);
                break;
            case 8:
               	cout<<"\nTHANK YOU. VISIT AGAIN!\nHAVE A NICE DAY!\n";
                return 0;
            default:
                	cout<<"\nINVALID CHOICE!! ENTER A CORRECT CHOICE FROM THE GIVEN OPTIONS.\n";
        }
    }
    return 0;
}


// ADD BOOK
void addbook(book* books, int* n) {
   
   	cout<<"Enter the number of books to add: ";
    cin >>*n;

    for (int i = 0; i < *n ; i++)
	{
       	cout<<"\nEnter ID of the book: ";
        cin>>books[i].id;

        	cout<<"Enter name of the book: ";
        cin>>books[i].bname;

        	cout<<"Enter author name of the book: ";
        cin>>books[i].author;

        	cout<<"Enter price of the book: ";
        cin>>books[i].price;

        	cout<<"Give the ratings for the book: ";
        cin>>books[i].ratings;

        	cout<<"Successfully added to the database.\n";
        
    }
}

//// DISPLAY ALL BOOKS
//void displayallbooks(book *b, int n) 
//    {
//    if (n == 0) {
//        printf("Library is empty.\n");
//        
//        return;
//    }
//
//    printf("THE AVAILABLE BOOKS ARE:\n");
//
//    printf("---------------------------------------------------------------------------------------------------------\n");
//printf("|  %-10s |  %-30s |  %-20s |  %-10s |  %-8s  |\n", "BOOK ID", "BOOK NAME", "AUTHOR NAME", "PRICE", "RATINGS");
//printf("|-----------------------------------------------------------------------------------------------------------|\n");
//for (int i = 0; i < n; i++) {
//    printf("|  %-10d |  %-30s |  %-20s |  %-10.2lf |  %-8d  |\n", b[i].id, b[i].bname, b[i].author, b[i].price, b[i].ratings);
//}
//printf("----------------------------------------------------------------------------------------------------------------------\n");
//
//}

// SEARCH BOOK BY ID 
void searchbookbyid(book *b, int n, int searchid) {
    int found = 0;

    for (int i = 0; i < n; i++) {
        if (b[i].id == searchid) {
        	
            b[i].display();
            found = 1;
            break;
        }
    }

    if (found == 0) {
        cout<<"Book with ID %d not found.\n"<< searchid;
    }
}

// SEARCH BOOK BY NAME 
void searchbookbyname(book *b, int n, char *searchName) {
    int found = 0;

    for (int i = 0; i < n; i++) {
        if (strcmp(b[i].bname, searchName) == 0) {
            b[i].display();
            found = 1;
        }
    }

    if (found == 0) {
        cout<<"No books found with the name: %s\n"<<searchName;
    }
}

// SEARCH BOOK BY AUTHOR NAME 
void searchbookbyauthor(book *b, int n, char *searchAuthor) {
    int found = 0;

    for (int i = 0; i < n; i++) {
        if (strcmp(b[i].author, searchAuthor) == 0) {
            b[i].display();
            found = 1;
        }
    }

    if (found == 0) {
    	
        cout<<"No books found by the author: %s\n"<<searchAuthor;
    }
}

// TOP 3 BOOKS BY PRICE (ascending order)
void top3byprice(book *b, int n) {
    if (n < 3) {
        cout<<"Sorry, at least 3 books are required for this operation.\n";
        return;
    }

    
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (b[j].price > b[j + 1].price) {
                book temp = b[j];
                b[j] = b[j + 1];
                b[j + 1] = temp;
            }
        }
    }

    cout<<"TOP 3 BOOKS BY PRICE :\n";
//   printf("----------------------------------------------------------------------------------------------\n");
//printf("|  %-10s |  %-30s |  %-20s |  %-10s |  %-8s  |\n", "BOOK ID", "BOOK NAME", "AUTHOR NAME", "PRICE", "RATINGS");
//printf("|--------------------------------------------------------------------------------------------|\n");
//for (int i = 0; i < 3; i++) {
//    printf("|  %-10d |  %-30s |  %-20s |  %-10.2lf |  %-8d  |\n", b[i].id, b[i].bname, b[i].author, b[i].price, b[i].ratings);
//}
//printf("----------------------------------------------------------------------------------------------\n");
 for (int i = 0; i < 3; i++) 
    {
b[i].display();

}
}

// TOP 3 BOOKS BY RATINGS (descending order)B
void top3byratings(book *b, int n) 
{
    if (n < 3) 
	{
        cout<<"Sorry, at least 3 books are required for this operation.\n";
        return;
    }

    for (int i = 0; i < n - 1; i++) 
	{
        for (int j = 0; j < n - i - 1; j++) 
		{
            if (b[j].ratings < b[j + 1].ratings)
			 {
                book temp = b[j];
                b[j] = b[j + 1];
                b[j + 1] = temp;
            }
        }
    }

    cout<<"TOP 3 BOOKS BY RATINGS :\n";
//   printf("----------------------------------------------------------------------------------------------\n");
//printf("|  %-10s |  %-30s |  %-20s |  %-10s |  %-8s  |\n", "BOOK ID", "BOOK NAME", "AUTHOR NAME", "PRICE", "RATINGS");
//printf("|--------------------------------------------------------------------------------------------|\n");
//for (int i = 0; i < 3; i++) {
//    printf("|  %-10d |  %-30s |  %-20s |  %-10.2lf |  %-8d  |\n", b[i].id, b[i].bname, b[i].author, b[i].price, b[i].ratings);
//}
//printf("----------------------------------------------------------------------------------------------\n");
for (int i = 0; i < 3; i++) 
    {
b[i].display();

}
}
   
 // REMOVE BOOK
void removebook(book *b, int *n, int bookid) {
    int found = 0;

    for (int i = 0; i < *n; i++) {
        if (b[i].id == bookid) {
            for (int j = i; j < *n - 1; j++) {
                b[j] = b[j + 1];
            }
            (*n)--;
            found = 1;
           cout<<"Book with ID %d has been removed from the library.\n";
            break;
        }
    }

    if (found == 0) {
        cout<<"Book with ID %d not found in the library.\n";
    }
}


// UPDATE BOOK 
void updatebook(book *b, int n, int bookid, double newPrice, int newRatings) 
{
    int found = 0;

    for (int i = 0; i < n; i++) {
        if (b[i].id == bookid) 
		{
            
            b[i].price = newPrice;
            b[i].ratings = newRatings;
            found = 1;
            cout<<"Book with ID %d has been updated.\n";
            break;
        }
    }

    if (found == 0) {
        cout<<"Book with ID %d not found in the library. Update failed.\n";
    }
}
  